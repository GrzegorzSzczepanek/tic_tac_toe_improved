import socket

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("127.0.0.1", 9998))

server.listen(5)

print("it works")
while True:
    client, addr = server.accept()
    print("connected from ", addr)

    data = client.recv(1024)
    print("Received: ", data.decode())

    client.send("Hello ".encode())

    client.close()